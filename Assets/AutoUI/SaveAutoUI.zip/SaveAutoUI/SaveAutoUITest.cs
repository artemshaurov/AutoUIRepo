using System;
using Common.AutoUI.Runtime;
using Common.AutoUI.Samples;
using Common.SimpleDataPersistence.Runtime;
using UnityEngine;

namespace Common.AutoUI.SaveAutoUI
{
    public class SaveAutoUITest : MonoBehaviour
    {
        [SerializeField] private RectTransform m_Root;
        private const string m_TestDataKey = "auto_ui_test";
        
        private DataWrapper<TestClass> m_TestDataWrapper;
        
        private DataManager m_DataManager;
        private AutoUIController m_AutoUIController;
        private IAutoNode m_RootNode;

        private void Start()
        {
            m_DataManager = new DataManager(new DataManagerSettings
            {
                RootDataFolderName = "UserData",
                HistoryCapacity = 10,
                StrategyControllerSettings = new StrategyControllerSettings
                {
                    UpdateInterval = TimeSpan.FromSeconds(1),
                    StrategyInfos = new[]
                    {
                        new StrategyInfo
                        {
                            Strategy = new UnfocusSaveStrategy(),
                            Key = "UnfocusData"
                        },
                        new StrategyInfo
                        {
                            Strategy = new TimeSaveStrategy(TimeSpan.FromSeconds(60)),
                            Key = "60sData"
                        },
                        new StrategyInfo
                        {
                            Strategy = new TimeSaveStrategy(TimeSpan.FromSeconds(600)),
                            Key = "600sData"
                        }
                    }
                }
            });
            m_AutoUIController = new AutoUIController(new AutoUICollectionRefs());
            m_DataManager.LoadLocalData();
        }
        
        private void OnLoaded()
        {
            SetupTestData();
        }

        private void SetupTestData()
        {
            m_TestDataWrapper = m_DataManager.GetDataWrapper<TestClass>(m_TestDataKey);
            
            m_RootNode = m_AutoUIController
                .CreateUISchemeForObject(m_TestDataWrapper.Data, "AutoUI Save Test", m_Root);
        }

        private void OnGUI()
        {
            if (GUI.Button(new Rect(20, 50, 200, 100), "Save"))
            {
                Save();
            }
        }

        private void Save()
        {
            var deserialized = AutoUIController.Deserialize<TestClass>(m_RootNode);
            m_TestDataWrapper.OverwriteData(deserialized);
        }
    }
}